import json
from pathlib import Path


def write_page_data(
    id_type: str, folder: Path, page: dict, offset: int, page_size: int
):
    folder_name = folder.name
    page_proc = {entry[id_type]: entry for entry in page}
    file_name = f'{folder_name}_page_{offset}_{offset+page_size}.json'
    file_path = folder / file_name
    write_to_json(file_path=file_path, dump=page_proc)


def write_task_data(folder: Path, files: dict, task: dict):
    for file_name, file in files.items():
        file_path = folder / file_name
        with file_path.open('wb') as fid:
            fid.write(file)
    file_path = folder / 'metadata.json'
    write_to_json(file_path=file_path, dump=task)


def write_to_json(file_path: Path, dump: dict):
    with file_path.open('w') as fid:
        json.dump(dump, fid, indent=4)
