import requests


def get_bearer_token(url: str, email: str, password: str, expires_in: int) -> str:
    response = requests.post(
        url,
        data={'grant_type': 'client_credentials', 'expires_in': expires_in},
        auth=(email, password),
    )
    response.raise_for_status()
    return response.json()['access_token']


def get_headers(token: str):
    return {
        'Content-Type': 'application/json',
        'Authorization': f'Bearer {token}',
    }
