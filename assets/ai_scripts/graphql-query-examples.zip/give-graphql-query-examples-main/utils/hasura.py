from typing import Generator

import requests

from utils.auth import get_headers
from utils.queries import NER_PRESIGN_S3_QUERY, SPEECH_PRESIGN_S3_QUERY


def yield_results_pages(
    url: str,
    token: str,
    view: str,
    query: str,
    variables: dict,
    page_size: int,
    include_failed=False,
) -> Generator:
    # only task based views need the status variable,
    if (
        view != 'face_matches'
        and view != 'refset_persons'
        and view != 'face_image_matches'
    ):
        statuses = ['succeeded']
        if include_failed:
            statuses = statuses.append('failed')
        variables['status'] = statuses

    # create a session and prepare the headers
    session = requests.session()
    headers = get_headers(token=token)

    while True:
        # do a request to get the next page
        response = session.post(
            url,
            json={'query': query, 'variables': variables},
            headers=headers,
            params={'jwtauth': token}
        )
        response.raise_for_status()
        results = response.json()['data'][view]

        if not results:
            # no more results
            break

        # yield the page of results
        yield results, variables['offset']

        variables['offset'] += page_size

    # make sure to close the session
    session.close()


def get_presigned_urls_by_task_id(
    url: str, token: str, view: str, task_id: str
) -> dict:
    if view == 'ner_tasks':
        variables = {
            'processed_json': f'{task_id}/processed.json',
            'textrazor_json': f'{task_id}/textrazor.json',
        }
    elif view == 'speech_tasks':
        variables = {
            'transcript_json': f'{task_id}/transcript.json',
            'transcript_srt': f'{task_id}/transcript.srt',
            'transcript_txt': f'{task_id}/transcript.txt',
            'transcript_vtt': f'{task_id}/transcript.vtt',
            'audio_classification_json': f'{task_id}/audio_classification.json',
        }
    else:
        raise ValueError('Unknown view for presigned urls.')

    headers = get_headers(token=token)
    query = NER_PRESIGN_S3_QUERY if view == 'ner_tasks' else SPEECH_PRESIGN_S3_QUERY
    response = requests.post(
        url,
        json={
            'query': query,
            'variables': variables,
        },
        headers=headers,
    )
    response.raise_for_status()
    presigned_urls = response.json()['data']['presignS3']
    return presigned_urls[0]
