NER_PRESIGN_S3_QUERY = """
query GetPresignS3(
    $processed_json: String!,
    $textrazor_json: String!
) {
    presignS3(
        urls_sets: {
            processed_json: $processed_json,
            textrazor_json: $textrazor_json
        }
    ) {
        presigned_processed_json
        presigned_textrazor_json
    }
}
"""

SPEECH_PRESIGN_S3_QUERY = """
query GetPresignS3(
    $transcript_json: String!,
    $transcript_srt: String!,
    $transcript_txt: String!,
    $transcript_vtt: String!,
    $audio_classification_json: String!
) {
    presignS3(
        urls_sets: {
            transcript_json: $transcript_json,
            transcript_srt: $transcript_srt,
            transcript_txt: $transcript_txt,
            transcript_vtt: $transcript_vtt,
            audio_classification_json: $audio_classification_json
        }
    ) {
        presigned_json
        presigned_srt
        presigned_txt
        presigned_vtt
        presigned_audio_classification_json
    }
}
"""

FACE_MATCHES_QUERY = """
query GetFaceMatches($limit: Int!, $offset: Int!) {
  face_matches(
        limit: $limit
        offset: $offset
  ) {
    cluster_uuid
    cp
    match_score
    refset_person_id
    refset_person_name
    refset_person_wiki_id
    time_intervals
    matched_time
  }
}
"""

FACE_IMAGE_MATCHES_QUERY = """
query GetFaceImageMatches($limit: Int!, $offset: Int!) {
  face_image_matches(
        limit: $limit
        offset: $offset
  ) {
    cluster_uuid
    cp
    match_score
    matched_time
    refset_person_id
    refset_person_name
    refset_person_wiki_id
    time_intervals
  }
}
"""

FACE_TASKS_QUERY = """
query GetFaceTasks($limit: Int!, $offset: Int!, $status: [String!]) {
  face_tasks(
        limit: $limit
        offset: $offset
        where: {
          status: {
            _in: $status
            }
        }
  ) {
    task_id,
    processed_time,
    cp
    status
    error
    pid
    n_faces
    n_persons
    n_scenes
    cluster_uuids
    n_faces_per_frame
    n_persons_per_frame
    perc_frames_with_faces
    media_object_id
    main_local_id
    external_id
    title
  }
}
"""

FACE_IMAGE_TASKS_QUERY = """
query GetFaceImageTasks($limit: Int!, $offset: Int!, $status: [String!]) {
  face_image_tasks(
        limit: $limit
        offset: $offset
        where: {
          status: {
            _in: $status
            }
        }
  ) {
    cluster_uuids
    cp
    error
    external_id
    main_local_id
    media_object_id
    n_faces
    n_faces_per_frame
    n_persons
    n_persons_per_frame
    n_scenes
    perc_frames_with_faces
    pid
    processed_time
    status
    task_id
    title
  }
}
"""

NER_TASKS_QUERY = """
query GetNerTasks($limit: Int!, $offset: Int!, $status: [String!]) {
  ner_tasks(
        limit: $limit
        offset: $offset
        where: {
          status: {
            _in: $status
            }
        }
  ) {
    task_id
    processed_time
    cp
    status
    error
    pid
    fragment_id
    processed_json
    textrazor_json
  }
}
"""

REFSET_PERSONS_QUERY = """
query GetRefsetPersons($limit: Int!, $offset: Int!) {
  refset_persons(
        limit: $limit
        offset: $offset
  ) {
      id
      description
      status
      created_at
      modified_at
      label
      public_links
  }
}
"""

SPEECH_TASKS_QUERY = """
query GetSpeechTasks($limit: Int!, $offset: Int!, $status: [String!]) {
  speech_tasks(
        limit: $limit
        offset: $offset
        where: {
          status: {
            _in: $status
            }
        }
  ) {
    task_id
    processed_time
    cp
    status
    error
    pid
    media_object_id
    main_local_id
    external_id
    title
    fragment_id
    transcript_json
    transcript_srt
    transcript_txt
    transcript_vtt
    audio_classification_json
    statistics
  }
}
"""
